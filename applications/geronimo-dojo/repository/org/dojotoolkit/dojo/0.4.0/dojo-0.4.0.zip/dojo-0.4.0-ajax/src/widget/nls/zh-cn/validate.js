/*
	Copyright (c) 2004-2006, The Dojo Foundation
	All Rights Reserved.

	Licensed under the Academic Free License version 2.1 or above OR the
	modified BSD license. For more information on Dojo licensing, see:

		http://dojotoolkit.org/community/licensing.shtml
*/

﻿({
		invalidMessage: "* 非法的输入值。",
		missingMessage: "* 此值是必须的。",
		rangeMessage: "* 输入数据超出值域。"
})
