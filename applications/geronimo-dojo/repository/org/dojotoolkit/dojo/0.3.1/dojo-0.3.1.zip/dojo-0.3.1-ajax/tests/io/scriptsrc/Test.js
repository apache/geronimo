/*
	Copyright (c) 2004-2006, The Dojo Foundation
	All Rights Reserved.

	Licensed under the Academic Free License version 2.1 or above OR the
	modified BSD license. For more information on Dojo licensing, see:

		http://dojotoolkit.org/community/licensing.shtml
*/

myTasks = new Array();
myTasks[0] = 'Take out trash.';
myTasks[1] = 'Do dishes.';
myTasks[2] = 'Brush teeth.';

