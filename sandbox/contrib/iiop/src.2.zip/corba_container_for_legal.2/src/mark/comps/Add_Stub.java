/*
 *  Copyright 2004 The Apache Software Foundation or its licensors, as
 *  applicable.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
 *  implied.
 *
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package mark.comps;

import gcc.rmi.iiop.ObjectRef;
import gcc.rmi.iiop.client.Connection;
import gcc.properties.PropertyMap;
import mark.AddData;

import javax.ejb.EJBHome;
import javax.ejb.RemoveException;
import javax.ejb.Handle;
import javax.ejb.EJBObject;
import java.rmi.RemoteException;

public class Add_Stub
    extends ObjectRef
    implements Add
{
    // 
    // Fields
    // 
    public java.lang.String[] _ids = { "mark.comps.Add", "RMI:mark.comps.Add:0000000000000000"};
    private static final gcc.rmi.iiop.ValueType vt$1 = gcc.rmi.iiop.ValueType.getInstance(java.lang.String.class);

    //
    // Constructors
    // 
    public Add_Stub( )
    {
        super();
    }
    
    // 
    // Methods
    // 
    
    public void $invoke( java.lang.String methodName, byte[] objectKey, java.lang.Object instance, gcc.rmi.iiop.ObjectInputStream input, gcc.rmi.iiop.ObjectOutputStream output )
    {
    }

    public boolean _is_a(java.lang.String p1)
    {
        java.lang.Object $key_1 = $getRequestKey();
        for (int $retry = 0; ; $retry++)
        {
            try
            {
                gcc.rmi.iiop.client.Connection $connection_2 = this.$connect();
                gcc.rmi.iiop.ObjectOutputStream $output_3 = $connection_2.getSimpleOutputStream();
                $output_3.writeObject(vt$1, p1);
                $connection_2.invoke(this, "_is_a", $key_1, $retry);
                gcc.rmi.iiop.ObjectInputStream $input_4 = $connection_2.getSimpleInputStream();
                $connection_2.forget($key_1);
                $connection_2.close();
                java.lang.String $et_5 = $connection_2.getExceptionType();
                if ($et_5 != null)
                {
                    throw gcc.rmi.iiop.SystemExceptionFactory.getException($connection_2.getException());
                }
                boolean $djc_result;
                $djc_result = $input_4.readBoolean();
                return $djc_result;
            }
            catch (gcc.rmi.iiop.client.RetryInvokeException $ex_6)
            {
                if ($retry == 3)
                {
                    throw $ex_6.getRuntimeException();
                }
            }
        }
    }

    public int add( int p0, int p1 )
    {
        java.lang.Object $key_1 = $getRequestKey();
        for (int $retry = 0; ; $retry++)
        {
            try
            {
                gcc.rmi.iiop.client.Connection connection = this.$connect();
                gcc.rmi.iiop.ObjectOutputStream output = connection.getOutputStream();
                output.writeInt(p0);
                output.writeInt(p1);
                connection.invoke( this, "add", $key_1, $retry );
                gcc.rmi.iiop.ObjectInputStream input = connection.getInputStream();
                connection.forget( $key_1 );
                connection.close();
                java.lang.String et = connection.getExceptionType();
                if (et != null)
                {
                    throw gcc.rmi.iiop.SystemExceptionFactory.getException(connection.getException());
                }
                int rc;
                rc = input.readInt();
                return rc;
            }
            catch (gcc.rmi.iiop.client.RetryInvokeException $ex_6)
            {
                if ($retry == 3)
                {
                    throw $ex_6.getRuntimeException();
                }
            }
        }
    }

    public AddData addData(AddData a, AddData b) throws RemoteException
    {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public AddData addDatas(AddData a[]) throws RemoteException
    {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void mVOID() throws RemoteException
    {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public int mINT() throws RemoteException
    {
        return 0;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public double mDOUBLE() throws RemoteException
    {
        return 0;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public float mFLOAT() throws RemoteException
    {
        return 0;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public long mLONG() throws RemoteException
    {
        return 0;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public char mCHAR() throws RemoteException
    {
        return 0;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public boolean mBOOLEAN() throws RemoteException
    {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public byte mBYTE() throws RemoteException
    {
        return 0;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String mSTRING() throws RemoteException
    {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void mEXCEPTION() throws RemoteException
    {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void mNONE() throws RemoteException
    {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void mONE(int a) throws RemoteException
    {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void mTWO(int a, int b) throws RemoteException
    {
        //To change body of implemented methods use File | Settings | File Templates.
    }


    public EJBHome getEJBHome() throws RemoteException
    {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Object getPrimaryKey() throws RemoteException
    {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void remove() throws RemoteException, RemoveException
    {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public Handle getHandle() throws RemoteException
    {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public boolean isIdentical(EJBObject ejbObject) throws RemoteException
    {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }
}
