/*
 *  Copyright 2004 The Apache Software Foundation or its licensors, as
 *  applicable.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
 *  implied.
 *
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package gcc.org.omg.CosNaming.iiop_stubs;

import gcc.rmi.iiop.ObjectRef;

public class NamingContext_Stub
    extends ObjectRef
    implements gcc.org.omg.CosNaming.NamingContext
{
    // 
    // Fields
    // 
    public java.lang.String[] _ids = { "gcc.org.omg.CosNaming.NamingContext", "RMI:gcc.org.omg.CosNaming.NamingContext:0000000000000000"};
    private static final gcc.rmi.iiop.ValueType vt$0 = gcc.rmi.iiop.ValueType.getInstance( java.lang.String.class );
    private static final gcc.rmi.iiop.ValueType vt$1 = gcc.rmi.iiop.ValueType.getInstance( gcc.org.omg.CosNaming.BindingListHolder.class );
    private static final gcc.rmi.iiop.ValueType vt$2 = gcc.rmi.iiop.ValueType.getInstance( gcc.org.omg.CosNaming.BindingIteratorHolder.class );
    private static final gcc.rmi.iiop.ValueType vt$3 = gcc.rmi.iiop.ValueType.getInstance( gcc.org.omg.CosNaming.NameComponent[].class );
    private static final gcc.rmi.iiop.ValueType vt$4 = gcc.rmi.iiop.ValueType.getInstance( org.omg.CORBA.Object.class );
    private static final gcc.rmi.iiop.ValueType vt$5 = gcc.rmi.iiop.ValueType.getInstance( gcc.org.omg.CosNaming.NamingContext.class );
    
    // 
    // Constructors
    // 
    public NamingContext_Stub( )
    {
        super();
    }
    
    // 
    // Methods
    // 
    
    public boolean _is_a( java.lang.String id )
    {
        java.lang.Object $key = $getRequestKey();
        int $retry;
        
        for ($retry = 0
        ; ; $retry++
        )
        {
            
            try
            {
                gcc.rmi.iiop.client.Connection $conn;
                gcc.rmi.iiop.ObjectOutputStream $out;
                java.lang.String $et;
                boolean $rc;
                gcc.rmi.iiop.ObjectInputStream $in;
                $conn = this.$connect();
                $out = $conn.getSimpleOutputStream();
                $out.writeObject( vt$0, id);
                $conn.invoke(this, "_is_a", $key, $retry);
                $in = $conn.getSimpleInputStream();
                $conn.forget($key);
                $conn.close();
                $et = $conn.getExceptionType();
                
                if ($et != null)
                {
                    throw gcc.rmi.iiop.SystemExceptionFactory.getException($conn.getException());
                }
                $rc = $in.readBoolean();
                return $rc;
            }
            catch( gcc.rmi.iiop.client.RetryInvokeException $ex )
            {
                
                if ($retry == 3)
                {
                    throw $ex.getRuntimeException();
                }
            }
        }
    }
    
    public void list( int p0, gcc.org.omg.CosNaming.BindingListHolder p1, gcc.org.omg.CosNaming.BindingIteratorHolder p2 )
    {
        java.lang.Object $key = $getRequestKey();
        int $retry;
        
        for ($retry = 0
        ; ; $retry++
        )
        {
            
            try
            {
                gcc.rmi.iiop.client.Connection $conn;
                gcc.rmi.iiop.ObjectOutputStream $out;
                java.lang.String $et;
                $conn = this.$connect();
                $out = $conn.getSimpleOutputStream();
                $out.writeInt( p0 );
                $out.writeObject( vt$1, p1);
                $out.writeObject( vt$2, p2);
                $conn.invoke(this, "list", $key, $retry);
                $conn.forget($key);
                $conn.close();
                $et = $conn.getExceptionType();
                
                if ($et != null)
                {
                    throw gcc.rmi.iiop.SystemExceptionFactory.getException($conn.getException());
                }
            }
            catch( gcc.rmi.iiop.client.RetryInvokeException $ex )
            {
                
                if ($retry == 3)
                {
                    throw $ex.getRuntimeException();
                }
            }
        }
    }
    
    public org.omg.CORBA.Object resolve( gcc.org.omg.CosNaming.NameComponent[] p0 ) throws gcc.org.omg.CosNaming.NamingContextPackage.NotFound, gcc.org.omg.CosNaming.NamingContextPackage.CannotProceed, gcc.org.omg.CosNaming.NamingContextPackage.InvalidName
    {
        java.lang.Object $key = $getRequestKey();
        int $retry;
        
        for ($retry = 0
        ; ; $retry++
        )
        {
            
            try
            {
                gcc.rmi.iiop.client.Connection $conn;
                gcc.rmi.iiop.ObjectOutputStream $out;
                java.lang.String $et;
                org.omg.CORBA.Object $rc;
                gcc.rmi.iiop.ObjectInputStream $in;
                $conn = this.$connect();
                $out = $conn.getSimpleOutputStream();
                $out.writeObject( vt$3, p0);
                $conn.invoke(this, "resolve", $key, $retry);
                $in = $conn.getSimpleInputStream();
                $conn.forget($key);
                $conn.close();
                $et = $conn.getExceptionType();
                
                if ($et != null)
                {
                    throw gcc.rmi.iiop.SystemExceptionFactory.getException($conn.getException());
                }
                $rc = (org.omg.CORBA.Object)$in.readObject( vt$4);
                return $rc;
            }
            catch( gcc.rmi.iiop.client.RetryInvokeException $ex )
            {
                
                if ($retry == 3)
                {
                    throw $ex.getRuntimeException();
                }
            }
        }
    }
    
    public void bind( gcc.org.omg.CosNaming.NameComponent[] p0, org.omg.CORBA.Object p1 ) throws gcc.org.omg.CosNaming.NamingContextPackage.NotFound, gcc.org.omg.CosNaming.NamingContextPackage.CannotProceed, gcc.org.omg.CosNaming.NamingContextPackage.InvalidName, gcc.org.omg.CosNaming.NamingContextPackage.AlreadyBound
    {
        java.lang.Object $key = $getRequestKey();
        int $retry;
        
        for ($retry = 0
        ; ; $retry++
        )
        {
            
            try
            {
                gcc.rmi.iiop.client.Connection $conn;
                gcc.rmi.iiop.ObjectOutputStream $out;
                java.lang.String $et;
                $conn = this.$connect();
                $out = $conn.getSimpleOutputStream();
                $out.writeObject( vt$3, p0);
                $out.writeObject( vt$4, p1);
                $conn.invoke(this, "bind", $key, $retry);
                $conn.forget($key);
                $conn.close();
                $et = $conn.getExceptionType();
                
                if ($et != null)
                {
                    throw gcc.rmi.iiop.SystemExceptionFactory.getException($conn.getException());
                }
            }
            catch( gcc.rmi.iiop.client.RetryInvokeException $ex )
            {
                
                if ($retry == 3)
                {
                    throw $ex.getRuntimeException();
                }
            }
        }
    }
    
    public void bind_context( gcc.org.omg.CosNaming.NameComponent[] p0, gcc.org.omg.CosNaming.NamingContext p1 ) throws gcc.org.omg.CosNaming.NamingContextPackage.NotFound, gcc.org.omg.CosNaming.NamingContextPackage.CannotProceed, gcc.org.omg.CosNaming.NamingContextPackage.InvalidName, gcc.org.omg.CosNaming.NamingContextPackage.AlreadyBound
    {
        java.lang.Object $key = $getRequestKey();
        int $retry;
        
        for ($retry = 0
        ; ; $retry++
        )
        {
            
            try
            {
                gcc.rmi.iiop.client.Connection $conn;
                gcc.rmi.iiop.ObjectOutputStream $out;
                java.lang.String $et;
                $conn = this.$connect();
                $out = $conn.getSimpleOutputStream();
                $out.writeObject( vt$3, p0);
                $out.writeObject( vt$5, p1);
                $conn.invoke(this, "bind_context", $key, $retry);
                $conn.forget($key);
                $conn.close();
                $et = $conn.getExceptionType();
                
                if ($et != null)
                {
                    throw gcc.rmi.iiop.SystemExceptionFactory.getException($conn.getException());
                }
            }
            catch( gcc.rmi.iiop.client.RetryInvokeException $ex )
            {
                
                if ($retry == 3)
                {
                    throw $ex.getRuntimeException();
                }
            }
        }
    }
    
    public void rebind( gcc.org.omg.CosNaming.NameComponent[] p0, org.omg.CORBA.Object p1 ) throws gcc.org.omg.CosNaming.NamingContextPackage.NotFound, gcc.org.omg.CosNaming.NamingContextPackage.CannotProceed, gcc.org.omg.CosNaming.NamingContextPackage.InvalidName
    {
        java.lang.Object $key = $getRequestKey();
        int $retry;
        
        for ($retry = 0
        ; ; $retry++
        )
        {
            
            try
            {
                gcc.rmi.iiop.client.Connection $conn;
                gcc.rmi.iiop.ObjectOutputStream $out;
                java.lang.String $et;
                $conn = this.$connect();
                $out = $conn.getSimpleOutputStream();
                $out.writeObject( vt$3, p0);
                $out.writeObject( vt$4, p1);
                $conn.invoke(this, "rebind", $key, $retry);
                $conn.forget($key);
                $conn.close();
                $et = $conn.getExceptionType();
                
                if ($et != null)
                {
                    throw gcc.rmi.iiop.SystemExceptionFactory.getException($conn.getException());
                }
            }
            catch( gcc.rmi.iiop.client.RetryInvokeException $ex )
            {
                
                if ($retry == 3)
                {
                    throw $ex.getRuntimeException();
                }
            }
        }
    }
    
    public void rebind_context( gcc.org.omg.CosNaming.NameComponent[] p0, gcc.org.omg.CosNaming.NamingContext p1 ) throws gcc.org.omg.CosNaming.NamingContextPackage.NotFound, gcc.org.omg.CosNaming.NamingContextPackage.CannotProceed, gcc.org.omg.CosNaming.NamingContextPackage.InvalidName
    {
        java.lang.Object $key = $getRequestKey();
        int $retry;
        
        for ($retry = 0
        ; ; $retry++
        )
        {
            
            try
            {
                gcc.rmi.iiop.client.Connection $conn;
                gcc.rmi.iiop.ObjectOutputStream $out;
                java.lang.String $et;
                $conn = this.$connect();
                $out = $conn.getSimpleOutputStream();
                $out.writeObject( vt$3, p0);
                $out.writeObject( vt$5, p1);
                $conn.invoke(this, "rebind_context", $key, $retry);
                $conn.forget($key);
                $conn.close();
                $et = $conn.getExceptionType();
                
                if ($et != null)
                {
                    throw gcc.rmi.iiop.SystemExceptionFactory.getException($conn.getException());
                }
            }
            catch( gcc.rmi.iiop.client.RetryInvokeException $ex )
            {
                
                if ($retry == 3)
                {
                    throw $ex.getRuntimeException();
                }
            }
        }
    }
    
    public void unbind( gcc.org.omg.CosNaming.NameComponent[] p0 ) throws gcc.org.omg.CosNaming.NamingContextPackage.NotFound, gcc.org.omg.CosNaming.NamingContextPackage.CannotProceed, gcc.org.omg.CosNaming.NamingContextPackage.InvalidName
    {
        java.lang.Object $key = $getRequestKey();
        int $retry;
        
        for ($retry = 0
        ; ; $retry++
        )
        {
            
            try
            {
                gcc.rmi.iiop.client.Connection $conn;
                gcc.rmi.iiop.ObjectOutputStream $out;
                java.lang.String $et;
                $conn = this.$connect();
                $out = $conn.getSimpleOutputStream();
                $out.writeObject( vt$3, p0);
                $conn.invoke(this, "unbind", $key, $retry);
                $conn.forget($key);
                $conn.close();
                $et = $conn.getExceptionType();
                
                if ($et != null)
                {
                    throw gcc.rmi.iiop.SystemExceptionFactory.getException($conn.getException());
                }
            }
            catch( gcc.rmi.iiop.client.RetryInvokeException $ex )
            {
                
                if ($retry == 3)
                {
                    throw $ex.getRuntimeException();
                }
            }
        }
    }
    
    public gcc.org.omg.CosNaming.NamingContext new_context( )
    {
        java.lang.Object $key = $getRequestKey();
        int $retry;
        
        for ($retry = 0
        ; ; $retry++
        )
        {
            
            try
            {
                gcc.rmi.iiop.client.Connection $conn;
                gcc.rmi.iiop.ObjectOutputStream $out;
                java.lang.String $et;
                gcc.org.omg.CosNaming.NamingContext $rc;
                gcc.rmi.iiop.ObjectInputStream $in;
                $conn = this.$connect();
                $out = $conn.getSimpleOutputStream();
                $conn.invoke(this, "new_context", $key, $retry);
                $in = $conn.getSimpleInputStream();
                $conn.forget($key);
                $conn.close();
                $et = $conn.getExceptionType();
                
                if ($et != null)
                {
                    throw gcc.rmi.iiop.SystemExceptionFactory.getException($conn.getException());
                }
                $rc = (gcc.org.omg.CosNaming.NamingContext)$in.readObject( vt$5);
                return $rc;
            }
            catch( gcc.rmi.iiop.client.RetryInvokeException $ex )
            {
                
                if ($retry == 3)
                {
                    throw $ex.getRuntimeException();
                }
            }
        }
    }
    
    public gcc.org.omg.CosNaming.NamingContext bind_new_context( gcc.org.omg.CosNaming.NameComponent[] p0 ) throws gcc.org.omg.CosNaming.NamingContextPackage.NotFound, gcc.org.omg.CosNaming.NamingContextPackage.AlreadyBound, gcc.org.omg.CosNaming.NamingContextPackage.CannotProceed, gcc.org.omg.CosNaming.NamingContextPackage.InvalidName
    {
        java.lang.Object $key = $getRequestKey();
        int $retry;
        
        for ($retry = 0
        ; ; $retry++
        )
        {
            
            try
            {
                gcc.rmi.iiop.client.Connection $conn;
                gcc.rmi.iiop.ObjectOutputStream $out;
                java.lang.String $et;
                gcc.org.omg.CosNaming.NamingContext $rc;
                gcc.rmi.iiop.ObjectInputStream $in;
                $conn = this.$connect();
                $out = $conn.getSimpleOutputStream();
                $out.writeObject( vt$3, p0);
                $conn.invoke(this, "bind_new_context", $key, $retry);
                $in = $conn.getSimpleInputStream();
                $conn.forget($key);
                $conn.close();
                $et = $conn.getExceptionType();
                
                if ($et != null)
                {
                    throw gcc.rmi.iiop.SystemExceptionFactory.getException($conn.getException());
                }
                $rc = (gcc.org.omg.CosNaming.NamingContext)$in.readObject( vt$5);
                return $rc;
            }
            catch( gcc.rmi.iiop.client.RetryInvokeException $ex )
            {
                
                if ($retry == 3)
                {
                    throw $ex.getRuntimeException();
                }
            }
        }
    }
}
