Tests that work:

AddInterface\idl_hand\T1
    - Uses a corbaloc url from the ORB to obtain an object reference
    - java T1 -host localhost -port 9000 -intf

AddInterface\idl_hand\T2
    - Uses name service to obtain an object reference
    - java T1 -host localhost -port 9000 -cosnaming
