
package gcc.org.omg.CosNaming.iiop_stubs;

import gcc.rmi.iiop.ObjectRef;

public class NamingContext_Stub
    extends ObjectRef
    implements gcc.org.omg.CosNaming.NamingContext
{
    // 
    // Fields
    // 
    public java.lang.String[] _ids = { "gcc.org.omg.CosNaming.NamingContext", "RMI:gcc.org.omg.CosNaming.NamingContext:0000000000000000"};
    
    // 
    // Methods
    // 
    
    public java.lang.Boolean _is_a( java.lang.String id )
    {
        return false;
    }
}
