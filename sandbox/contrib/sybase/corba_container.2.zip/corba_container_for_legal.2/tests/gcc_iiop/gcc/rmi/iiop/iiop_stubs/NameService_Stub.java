
package gcc.rmi.iiop.iiop_stubs;

import gcc.rmi.iiop.ObjectRef;

public class NameService_Stub
    extends ObjectRef
    implements gcc.rmi.iiop.NameService
{
    // 
    // Fields
    // 
    public java.lang.String[] _ids = { "gcc.rmi.iiop.NameService", "RMI:gcc.rmi.iiop.NameService:0000000000000000"};
    
    // 
    // Methods
    // 
    
    public java.lang.Boolean _is_a( java.lang.String id )
    {
        return false;
    }
}
