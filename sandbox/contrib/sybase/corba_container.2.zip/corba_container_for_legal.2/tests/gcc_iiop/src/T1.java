
import javax.naming.*;

import mark.*;
import mark.comps.*;

public class T1
{
    protected String    _host;
    protected String    _port;
    protected String    _ior;

    public void setHost( String val )
    {
        _host = val;
    }

    public void setPort( String val )
    {
        _port = val;
    }

    public Context getInitialContext() 
        throws Exception
    {
        java.util.Properties p = new java.util.Properties();
        //p.put(Context.INITIAL_CONTEXT_FACTORY, "com.sybase.djc.client.InitialContextFactory");
        p.put(Context.INITIAL_CONTEXT_FACTORY, "gcc.client.InitialContextFactory");
        p.put(Context.PROVIDER_URL, _ior = "iiop://" + _host + ":" + _port );
        p.put(Context.SECURITY_PRINCIPAL, "uid" );
        p.put(Context.SECURITY_CREDENTIALS, "pwd" );
        return new InitialContext(p);
    }

    public void testInterface( )
        throws Exception
    {
        String name = "mark.comps.Add";

        Context nc = getInitialContext();

        Add a = (Add)nc.lookup( name);
        System.out.println( "a = " + a );

        System.out.println( "a.add(1,2) = " + a.add(1,2) );

        // I thought you should just be able to create an AddData and send it ... aparently not.
        //System.out.println( "a.addData( 1, 2 ) = " + a.addData( new AddDataImpl(1), new AddDataImpl(2) ).getA() );

        /*
        AddDataValueFactory advf = new AddDataDefaultFactory();
        AddData ad1 = advf.createAD( 1 );
        AddData ad2 = advf.createAD( 2 );
        System.out.println( "a.addData( 1, 2 ) = " + a.addData( ad1, ad2 ).J_a() );
        */
    }

    public static void main( String args[] )
        throws Exception
    {
        int i;

        T1 t1 = new T1();

        t1.setHost("localhost");
        t1.setPort("9000");

        for( i=0; i<args.length; i++ )
        {
            if (args[i].equals("-intf"))
            {
                t1.testInterface();
            }
            else if (args[i].equals("-host"))
            {
                t1.setHost( args[++i] );
            }
            else if (args[i].equals("-port"))
            {
                t1.setPort( args[++i] );
            }
            else
            {
                System.out.println( "Unknown option: " + args[i] );
            }
        }
    }

}
