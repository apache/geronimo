public class SysVars
{
    public static void main( String args[] )
    {
        java.util.Properties props = System.getProperties();
        java.util.Enumeration enum = props.keys();
        String key = "";

        while( enum != null && enum.hasMoreElements() )
        {
            key = (String)enum.nextElement();
            System.out.println( "name: " + key + ", value: " + System.getProperty( key ) );
        }
    }
}
