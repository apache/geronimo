package mark;

public class AddDataImpl extends AddData
{
    public AddDataImpl()
    {
        super();
    }

    public AddDataImpl( int a )
    {
        J_a = a;
    }

    public int J_a()
    {
        return J_a;
    }

    public void J_a( int a )
    {
        J_a = a;
    }
}

