
import org.omg.CORBA.ORB;
import org.omg.CosNaming.*;

import mark.*;
import mark.comps.*;

/*
 * java T1 -ORBInitRef Add=corbaloc:iiop:1.2@localhost:9000/mark.comps.Add
 *                     Add=corbaloc:iiop:1.2@localhost:9000/mark.comps.Add
 */ 

public class T1
{
    protected String    _host;
    protected String    _port;
    protected String    _ior;

    public void setHost( String val )
    {
        _host = val;
    }

    public void setPort( String val )
    {
        _port = val;
    }

    public void setIOR( String val )
    {
        _ior = val;
    }

    protected String getCORBALoc( String name )
    {
        return name + "=corbaloc:iiop:1.2@" + _host + ":" + _port + "/" + name;
    }

    public void testHome( )
        throws Exception
    {
        /*
        String name = "AddHome";
        String ref[] = { "-ORBInitRef", getCORBALoc(name) };
        ORB orb = ORB.init( ref, null );

        System.out.println( "corbaloc = " + ref[1] );
        System.out.println( "orb = " + orb );

        org.omg.CORBA.Object obj = orb.resolve_initial_references( name );
        System.out.println( "obj = " + obj );

        AddHome ah = AddHomeHelper.narrow( obj );
        System.out.println( "ah = " + ah );

        Add a = ah.create();
        System.out.println( "a = " + a );

        System.out.println( "a.add(1,2) = " + a.add(1,2) );
        */
    }

    public void testInterface( )
        throws Exception
    {
        String name = "mark.comps.Add";
        String ref[] = { "-ORBInitRef", getCORBALoc(name) };
        ORB orb = ORB.init( ref, null );

        System.out.println( "corbaloc = " + ref[1] );
        System.out.println( "orb = " + orb );

        org.omg.CORBA.Object obj = orb.resolve_initial_references( name );
        System.out.println( "obj = " + obj );

        Add a = AddHelper.narrow( obj );
        System.out.println( "a = " + a );

        System.out.println( "a.add(1,2) = " + a.add(1,2) );

        // I thought you should just be able to create an AddData and send it ... aparently not.
        //System.out.println( "a.addData( 1, 2 ) = " + a.addData( new AddDataImpl(1), new AddDataImpl(2) ).getA() );

        AddDataValueFactory advf = new AddDataDefaultFactory();
        AddData ad1 = advf.createAD( 1 );
        AddData ad2 = advf.createAD( 2 );
        System.out.println( "a.addData( 1, 2 ) = " + a.addData( ad1, ad2 ).J_a() );
    }

    public void testCosNaming()
        throws Exception
    {
    //    String ref[] = { "-ORBInitialPort", _port,
    //                     "-ORBInitialHost", _host };

        String name = "NameService";
        String ref[] = { "-ORBInitRef", getCORBALoc(name) };

        ORB orb = ORB.init( ref, null );

        NamingContext nctx = NamingContextHelper.narrow( orb.resolve_initial_references(name) );
        System.out.println( "nctx = " + nctx );

        if (nctx != null)
        {
            //NameComponent nc = new NameComponent( "RMI:mark.comps.Add:0000000000000000", "mark.comps.Add" );
            NameComponent nc = new NameComponent( "mark.comps.Add", "mark.comps.Add" );
            System.out.println( "nc = " + nc );

            if (nc != null)
            {
                org.omg.CORBA.Object o = nctx.resolve( new NameComponent[] {nc} );
                System.out.println( "o = " + o );

                Add ai = AddHelper.narrow( o );
                System.out.println( "ai = " + ai );

                System.out.println( "ai.add(1,2) = " + ai.add(1,2) );

                AddDataValueFactory advf = new AddDataDefaultFactory();
                AddData ad1 = advf.createAD( 1 );
                AddData ad2 = advf.createAD( 2 );
                System.out.println( "a.addData( 1, 2 ) = " + ai.addData( ad1, ad2 ).J_a() );
            }
        }
    }

    public void testIOR( )
        throws Exception
    {
        ORB orb = ORB.init( (String[])null, null );
        System.out.println( "orb = " + orb );

        org.omg.CORBA.Object obj = orb.string_to_object( _ior );
        System.out.println( "obj = " + obj );

        Add a = AddHelper.narrow( obj );
        System.out.println( "a = " + a );

        System.out.println( "a.add(1,2) = " + a.add(1,2) );
    }

    public static void main( String args[] )
        throws Exception
    {
        int i;

        T1 t1 = new T1();

        t1.setHost("localhost");
        t1.setPort("9000");

        for( i=0; i<args.length; i++ )
        {
            if (args[i].equals("-intf"))
            {
                t1.testInterface();
            }
            else if (args[i].equals("-home"))
            {
                t1.testHome();
            }
            else if (args[i].equals("-ior"))
            {
                if (i+1 < args.length)
                {
                    t1.setIOR( args[++i] );
                }
                else
                {
                    t1.setIOR( "IOR:000000000000000100000000000000010000000000000050000102000000000a6c6f63616c686f73740023280000000c416464496e746572666163650000000100000001000000200000000000010001000000020501000100010020000101090000000100010100" );
                }

                t1.testIOR();
            }
            else if (args[i].equals("-cosnaming"))
            {
                t1.testCosNaming();
            }
            else if (args[i].equals("-host"))
            {
                t1.setHost( args[++i] );
            }
            else if (args[i].equals("-port"))
            {
                t1.setPort( args[++i] );
            }
            else
            {
                System.out.println( "Unknown option: " + args[i] );
            }
        }
    }

}
