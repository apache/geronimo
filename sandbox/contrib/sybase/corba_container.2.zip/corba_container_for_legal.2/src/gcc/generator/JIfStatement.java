/*
 *  Copyright 2004 The Apache Software Foundation or its licensors, as
 *  applicable.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
 *  implied.
 *
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package gcc.generator;

public class JIfStatement extends JBlockStatement
{
    protected JExpression    _expr;

    public JIfStatement( JExpression e )
    {
        super();
        _expr = e;
    }

    public JExpression getExpression()
    {
        return _expr;
    }

    public int hashCode()
    {
        return _expr.hashCode();
    }

    public boolean equals( Object other )
    {
        boolean rc = false;

        if (this == other)
        {
            rc = true;
        }
        else if (other instanceof JIfStatement)
        {
            JIfStatement is = (JIfStatement)other;

            if (is._expr == _expr)
            {
                // Todo: Need equals()
                rc = true;
            }
        }

        return rc;
    }
}