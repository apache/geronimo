/*
 *  Copyright 2004 The Apache Software Foundation or its licensors, as
 *  applicable.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
 *  implied.
 *
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package mark.comps;

import gcc.rmi.iiop.ObjectInputStream;
import gcc.rmi.iiop.ObjectOutputStream;
import gcc.rmi.iiop.RemoteInterface;
import gcc.rmi.iiop.RemoteInterface;
import gcc.rmi.iiop.ObjectRef;
import gcc.rmi.iiop.RemoteObject;
import gcc.adapter.Adapter;
import java.util.HashMap;

import mark.AddData;
import mark.comps.Add2Impl;

public class Add2_Skeleton
    extends RemoteObject
    implements RemoteInterface
{
    //
    // Fields
    //
    public java.lang.String[] _ids = { "mark.comps.Add2", "RMI:mark.comps.Add2:0000000000000000"};
    public java.util.HashMap _methods = new HashMap(10);
    public Add2Impl _servant = null;
    public java.lang.String _f3 = "f1";
    public java.lang.String[] _f4 = { "f1", "f2" };
    public gcc.rmi.iiop.ValueType vt$0 = gcc.rmi.iiop.ValueType.getInstance( AddData.class );
    public gcc.rmi.iiop.ValueType vt$1 = gcc.rmi.iiop.ValueType.getInstance( AddData[].class );
    public gcc.rmi.iiop.ValueType vt$2 = gcc.rmi.iiop.ValueType.getInstance( java.lang.String.class );

    //
    // Constructors
    //
    public Add2_Skeleton( )
    {
        super();

        registerMethods();
    }

    protected void registerMethods()
    {
        super.registerMethods();

        registerMethod( "add", 0);
        registerMethod( "addData", 1);
        registerMethod( "addDatas", 2);
    }

    //
    // Methods
    //

    public void registerMethod( java.lang.String name, int id )
    {
        _methods.put( name, new Integer(id) );
    }

    public java.lang.String[] getIds( )
    {
        return _ids;
    }

    public RemoteInterface $getSkeleton( )
    {
        return this;
    }

    public ObjectRef $getObjectRef( )
    {
        gcc.rmi.iiop.ObjectRef or = new ObjectRef();
        or.$setID("RMI:mark.comps.Add2:0000000000000000");
        or.$setObjectKey("mark.comps.Add2");
        return or;
    }

    public void $invoke( java.lang.String methodName, byte[] objectKey, java.lang.Object instance, gcc.rmi.iiop.ObjectInputStream input, gcc.rmi.iiop.ObjectOutputStream output )
    {
        java.lang.Integer m = (Integer)_methods.get(methodName);
        if (m == null)
        {
            throw new org.omg.CORBA.BAD_OPERATION(methodName);
        }

        _servant = (mark.comps.Add2Impl)instance;

        if (m.intValue() < 0)
        {
            super.invoke( m.intValue(), objectKey, instance, input, output );
        }


        switch(m.intValue())
        {
            case 0:
            {
                add(input,output);
            }
            break;
            case 1:
            {
                addData(input,output);
            }
            break;
            case 2:
            {
                addDatas(input,output);
            }
            break;
        }
    }

    public void add( gcc.rmi.iiop.ObjectInputStream input, gcc.rmi.iiop.ObjectOutputStream output )
    {
        int rc;

        try
        {
            int p0 = input.readInt();
            int p1 = input.readInt();
            rc = _servant.add( p0, p1 );
            output.writeInt( rc );
        }
        catch( java.lang.Exception ex )
        {
            ex.printStackTrace();
        }
        catch( java.lang.Error er )
        {
            er.printStackTrace();
        }
    }

    public void addData( gcc.rmi.iiop.ObjectInputStream input, gcc.rmi.iiop.ObjectOutputStream output )
    {
        AddData rc;

        try
        {
            AddData p0 = (AddData) input.readObject( vt$0 );
            AddData p1 = (AddData) input.readObject( vt$0 );
            rc = _servant.addData( p0, p1 );
            output.writeObject( vt$0, rc );
        }
        catch( java.lang.Exception ex )
        {
            ex.printStackTrace();
        }
        catch( java.lang.Error er )
        {
            er.printStackTrace();
        }
    }

    public void addDatas( gcc.rmi.iiop.ObjectInputStream input, gcc.rmi.iiop.ObjectOutputStream output )
    {
        AddData rc;

        try
        {
            AddData[] p0 = (AddData[]) input.readObject( vt$1 );
            rc = _servant.addDatas( p0 );
            output.writeObject( vt$0, rc );
        }
        catch( java.lang.Exception ex )
        {
            ex.printStackTrace();
        }
        catch( java.lang.Error er )
        {
            er.printStackTrace();
        }
    }
}
