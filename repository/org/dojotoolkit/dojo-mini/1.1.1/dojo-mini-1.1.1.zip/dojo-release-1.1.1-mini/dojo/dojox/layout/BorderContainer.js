/*
	Copyright (c) 2004-2008, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/


if(!dojo._hasResource["dojox.layout.BorderContainer"]){dojo._hasResource["dojox.layout.BorderContainer"]=true;dojo.provide("dojox.layout.BorderContainer");console.error("dojox.layout.BorderContainer moved to dijit.layout.BorderContainer");}