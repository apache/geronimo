/*
	Copyright (c) 2004-2008, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/


if(!dojo._hasResource["dojox.av._base"]){dojo._hasResource["dojox.av._base"]=true;dojo.provide("dojox.av._base");dojo.require("dojox.av._base.flash");dojo.require("dojox.av._base.quicktime");}