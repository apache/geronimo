if(!dojo._hasResource["dojox.av"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojox.av"] = true;
dojo.provide("dojox.av");

dojo.require("dojox.av._base");

}
