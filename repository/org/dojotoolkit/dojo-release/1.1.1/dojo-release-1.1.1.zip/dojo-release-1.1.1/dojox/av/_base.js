if(!dojo._hasResource["dojox.av._base"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojox.av._base"] = true;
dojo.provide("dojox.av._base");

dojo.require("dojox.av._base.flash");
dojo.require("dojox.av._base.quicktime");

}
