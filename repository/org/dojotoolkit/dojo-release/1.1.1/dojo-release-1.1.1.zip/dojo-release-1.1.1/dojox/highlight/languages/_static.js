if(!dojo._hasResource["dojox.highlight.languages._static"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojox.highlight.languages._static"] = true;
dojo.provide("dojox.highlight.languages._static");

/* common static languages */
dojo.require("dojox.highlight.languages.cpp")
// dojo.require("dojox.highlight.languages.java");
dojo.require("dojox.highlight.languages.delphi");

}
