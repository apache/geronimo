if(!dojo._hasResource["dojox.highlight.languages._www"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojox.highlight.languages._www"] = true;
dojo.provide("dojox.highlight.languages._www");

/* common web-centric languages */
dojo.require("dojox.highlight.languages.xml");
dojo.require("dojox.highlight.languages.html");
dojo.require("dojox.highlight.languages.css");
dojo.require("dojox.highlight.languages.django");
dojo.require("dojox.highlight.languages.javascript");

}
