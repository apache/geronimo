if(!dojo._hasResource["dojox.encoding._base"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojox.encoding._base"] = true;
dojo.provide("dojox.encoding._base");



}
