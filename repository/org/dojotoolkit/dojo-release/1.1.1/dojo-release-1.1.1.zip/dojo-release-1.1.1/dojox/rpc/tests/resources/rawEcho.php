<?php
        print file_get_contents('php://input');

?>

