/*****************************************************************
 *   File: FileRetrieverConnectionFactory.java
 *   
 *   Date         Version   Author               Changes
 *   Oct.04,2005  1.1       Vladimir Shraibman   Created
 *
 *   Copyright (c) 2005, IBM Corporation
 *   All rights reserved.
 *****************************************************************/
package com.ibm.j2g.jca.connector;

import javax.resource.ResourceException;

/**
 * File Retriever connection factory interface
 * 
 * @author Vladimir B. Shraibman <shvb@isg.axmor.com>
 */
public interface FileRetrieverConnectionFactory {

    /**
     * Retrieves instance of the File Retriever connection
     * @return File Retriever connection instance
     * @throws ResourceException in case of any problem
     */
    public FileRetrieverConnection getConnection() throws ResourceException;
}
