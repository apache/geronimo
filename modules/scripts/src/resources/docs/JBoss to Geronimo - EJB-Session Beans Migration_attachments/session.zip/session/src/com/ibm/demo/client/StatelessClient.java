package com.ibm.demo.client;

import com.ibm.demo.session.stateless.LoanManagerHomeRemote;
import com.ibm.demo.session.stateless.LoanManagerRemote;

import javax.naming.InitialContext;
import javax.naming.Context;
import javax.naming.NamingException;
import javax.ejb.CreateException;
import javax.rmi.PortableRemoteObject;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Iterator;

/**
 * @author hisidro
 *
 */
public class StatelessClient {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		try{
			Context jndiContext = new InitialContext();   
			Object ref = jndiContext.lookup("LoanManagerHomeRemote");   
			LoanManagerHomeRemote home = (LoanManagerHomeRemote)
										  PortableRemoteObject.narrow(ref, LoanManagerHomeRemote.class);

			LoanManagerRemote loanmanager = home.create();
		
			// Get a list of all denied loans
			List deniedLoans = loanmanager.deniedLoans();
			
		    if(deniedLoans!=null){
				//CustomerRemote customer = null;
		    	String customer = new String();
		    	System.out.println("Customers with denied loan applications:");
				for(Iterator i = deniedLoans.iterator();i.hasNext();){
					customer = (String) i.next();
					System.out.println("- " + customer);
				}
		    }else{
		    	System.out.println("There are no denied loans in the database.");
		    }
		} catch(CreateException ce){
			ce.printStackTrace();
		} catch(RemoteException re){
			re.printStackTrace();
		} catch(NamingException ne){
			ne.printStackTrace();
		}
	}
}
