package com.ibm.demo.session.stateful;

import javax.ejb.*;
import java.rmi.RemoteException;
import java.util.Date;

/**
 * @author hisidro
 *
 */
public interface StatefulLoanManagerRemote extends EJBObject{

	/**
	 * @param id
	 * @param name
	 * @param address
	 * @param birthdate
	 * @param sssNo
	 * @param annualSalary
	 * @param loanAmount
	 * @throws RemoteException
	 */
	public void submitLoanApplication(Integer id, String name, String address, Date birthdate,
									  String sssNo, Double annualSalary, Double loanAmount) throws RemoteException;
	
	/**
	 * @return
	 * @throws RemoteException
	 */
	public int getSubmitCount() throws RemoteException;
	
	/**
	 * @return
	 * @throws RemoteException
	 */
	public int getMaxPK() throws RemoteException;
}