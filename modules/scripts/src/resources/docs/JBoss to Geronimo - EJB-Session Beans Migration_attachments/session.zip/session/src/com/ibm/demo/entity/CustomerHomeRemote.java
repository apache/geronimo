/*
 * Created on Sep 26, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.ibm.demo.entity;

import java.rmi.RemoteException;
import java.util.Date;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;
import javax.ejb.FinderException;

/**
 * @author cpineda
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
public interface CustomerHomeRemote extends EJBHome {

	/**
	 * 
	 * @param id
	 * @param name
	 * @param sssNo
	 * @param address
	 * @param birthdate
	 * @param annualSalary
	 * @param loanAmount
	 * @return
	 * @throws CreateException
	 * @throws RemoteException
	 */
	public CustomerRemote create(Integer id,String name,String sssNo,String address,Date birthdate,
								 Double annualSalary,Double loanAmount) throws CreateException,RemoteException;
	
	/**
	 * 
	 * @param primaryKey
	 * @return
	 * @throws CreateException
	 * @throws RemoteException
	 */
	public CustomerRemote create(Integer primaryKey)throws CreateException,RemoteException;

	/**
	 * 
	 * @param pk
	 * @return @throws
	 *         FinderException
	 * @throws RemoteException
	 */
	public CustomerRemote findByPrimaryKey(Integer pk) throws FinderException,
			RemoteException;

	/**
	 * 
	 * @param sssNo
	 * @return @throws
	 *         FinderException
	 * @throws RemoteException
	 */
	public CustomerRemote findBySssNo(String sssNo) throws FinderException,
			RemoteException;

}