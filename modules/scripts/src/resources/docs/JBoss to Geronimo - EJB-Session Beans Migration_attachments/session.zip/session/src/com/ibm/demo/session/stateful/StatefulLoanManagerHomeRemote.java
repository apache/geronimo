package com.ibm.demo.session.stateful;

import javax.ejb.*;
import java.rmi.RemoteException;

/**
 * @author hisidro
 * 
 */
public interface StatefulLoanManagerHomeRemote extends EJBHome {

	/**
	 * @return
	 * @throws RemoteException
	 * @throws CreateException
	 */
	public StatefulLoanManagerRemote create() throws RemoteException, CreateException;
}