package com.ibm.demo.client;

import java.io.*;
import java.rmi.RemoteException;
import java.util.Date;
import java.util.Random;

import javax.ejb.CreateException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

import com.ibm.demo.session.stateful.StatefulLoanManagerHomeRemote;
import com.ibm.demo.session.stateful.StatefulLoanManagerRemote;

public class StatefulClient {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Integer id = new Integer(0);
		String name = "";
		String sssNo = "";
		String address = "";
		Date birthdate = new Date();
		Double annualSalary = new Double(0.0);
		Double loanAmount = new Double(0.0);
		
		int startPK = 0;
		StatefulLoanManagerRemote loanmanager = null;
		Random generator = new Random();
		
		try{
			Context jndiContext = new InitialContext();   
			Object ref = jndiContext.lookup("StatefulLoanManagerHomeRemote");   
			StatefulLoanManagerHomeRemote home = (StatefulLoanManagerHomeRemote)
										  PortableRemoteObject.narrow(ref, StatefulLoanManagerHomeRemote.class);

			loanmanager = home.create();
			
		} catch(CreateException ce){
			ce.printStackTrace();
		} catch(RemoteException re){
			re.printStackTrace();
		} catch(NamingException ne){
			ne.printStackTrace();
		}
		
		
		//System.out.println("Please enter loan details:");
		
		try{
			startPK = loanmanager.getMaxPK();
		} catch (RemoteException re){
			re.printStackTrace();
		}
		for(int i=startPK + 1;i<startPK + generator.nextInt(14) + 1;i++){
			id = new Integer(i);
			name = "Customer" + i;
			address = "Address" + i;
			sssNo = "SSS:" + i;
			birthdate = new Date();
			annualSalary = new Double(generator.nextDouble() * 150000.0 + 20000.0);
			loanAmount = new Double(generator.nextDouble() * 1000000.0 + 50000.0);
			
			try{
				loanmanager.submitLoanApplication(id, name, address, birthdate, sssNo, annualSalary, loanAmount);
				System.out.println("Submitting new loan application...");
				System.out.println("-> submit count is now = " + loanmanager.getSubmitCount());
			}catch (RemoteException re){
				re.printStackTrace();
			}
		}
		
		try{
			System.out.println(loanmanager.getSubmitCount() + " loan applications were submitted.");
		}catch(RemoteException re){
			re.printStackTrace();
		}
	}
	
	public static String getInput(){
		// open up standard input
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		String input = null;
		// read the user input from the command-line; need to use try/catch with the
		// readLine() method
		try {
			input = br.readLine();
		}catch (IOException ioe) {
			System.out.println("IO error trying to read your input!");
			System.exit(1);
		}
		return input;
	}
		
}
