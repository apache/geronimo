package com.ibm.demo.client;

import java.io.*;
import java.rmi.RemoteException;
import java.util.Date;
import java.util.Random;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletException;
import javax.servlet.ServletContext;

import javax.ejb.CreateException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

import com.ibm.demo.session.stateful.StatefulLoanManagerHomeRemote;
import com.ibm.demo.session.stateful.StatefulLoanManagerRemote;


public class StatefulClientServlet extends HttpServlet {
	
	private ServletContext ctx;
	private int submitCount = 0;
	
	private StatefulLoanManagerRemote loanmanager;

	public void init() throws ServletException {

			this.ctx = getServletContext();	
			loanmanager = null;
			
			try{
				Context jndiContext = new InitialContext();   
				Object ref = jndiContext.lookup("java:/comp/env/ejb/StatefulLoanManagerHomeRemote");   
				StatefulLoanManagerHomeRemote home = (StatefulLoanManagerHomeRemote)
											  PortableRemoteObject.narrow(ref, StatefulLoanManagerHomeRemote.class);

				loanmanager = home.create();
			
			} catch(CreateException ce){
				ce.printStackTrace();
			} catch(RemoteException re){
				re.printStackTrace();
			} catch(NamingException ne){
				ne.printStackTrace();
			} catch(Exception e) {
	            e.printStackTrace();
	            throw new ServletException(e);
	        }
			
			
    }

	public void destroy() {

    }

    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	
    	Integer id = new Integer(0);
		String name = "";
		String sssNo = "";
		String address = "";
		Date birthdate = new Date();
		Double annualSalary = new Double(0.0);
		Double loanAmount = new Double(0.0);
    	
    	int startPK = 0;

		Random generator = new Random();
    	
    	try{
			startPK = loanmanager.getMaxPK();
		} catch (RemoteException re){
			re.printStackTrace();
		}
		for(int i=startPK + 1;i<startPK + generator.nextInt(14) + 1;i++){
			id = new Integer(i);
			name = "Customer" + i;
			address = "Address" + i;
			sssNo = "SSS:" + i;
			birthdate = new Date();
			annualSalary = new Double(generator.nextDouble() * 150000.0 + 20000.0);
			loanAmount = new Double(generator.nextDouble() * 1000000.0 + 50000.0);
			
			try{
				loanmanager.submitLoanApplication(id, name, address, birthdate, sssNo, annualSalary, loanAmount);
				System.out.println("Submitting new loan application...");
				System.out.println("-> submit count is now = " + loanmanager.getSubmitCount());
			}catch (RemoteException re){
				re.printStackTrace();
			}
		}
		
		try{
			submitCount = loanmanager.getSubmitCount();
		}catch (RemoteException re){
			re.printStackTrace();
		}
    	
    	request.setAttribute("count", new Integer(submitCount).toString());

        ctx.getRequestDispatcher("/stateful.jsp").include(request, response);
    }
		
}
