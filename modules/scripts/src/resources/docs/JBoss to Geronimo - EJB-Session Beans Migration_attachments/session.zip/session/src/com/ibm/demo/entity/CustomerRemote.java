/*
 * Created on Sep 26, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.ibm.demo.entity;

import java.util.Date;

import javax.ejb.EJBObject;
import java.rmi.RemoteException;

/**
 * @author cpineda
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
public interface CustomerRemote extends EJBObject {

	
	public void setName(String name) throws RemoteException;
	public String getName() throws RemoteException;
	
	public void setSssNo(String sssNo) throws RemoteException;
	public String getSssNo() throws RemoteException;
	
	public void setAddress(String address) throws RemoteException;
	public String getAddress() throws RemoteException;
	
	public void setBirthdate(Date birthdate) throws RemoteException;
	public Date getBirthdate() throws RemoteException;
	
	public void setAnnualSalary(Double annualSalary) throws RemoteException;
	public Double getAnnualSalary() throws RemoteException;
	
	public void setLoanAmount(Double loanAmount) throws RemoteException;
	public Double getLoanAmount() throws RemoteException;
	

}