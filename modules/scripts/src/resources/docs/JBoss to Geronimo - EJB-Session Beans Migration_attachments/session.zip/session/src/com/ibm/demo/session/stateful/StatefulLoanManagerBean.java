package com.ibm.demo.session.stateful;

import javax.ejb.*;
import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;

import java.rmi.RemoteException;
import java.util.Date;

import com.ibm.demo.entity.CustomerHomeRemote;
import com.ibm.demo.entity.CustomerRemote;

/**
 * @author hisidro
 *
 */
public class StatefulLoanManagerBean implements SessionBean{
	
	private int submit_count;
	
	public void ejbCreate(){
		this.submit_count = 0;
	}
	
	public void ejbRemove(){}
	public void ejbActivate(){}
	public void ejbPassivate(){}
	public void setSessionContext(SessionContext ctx){}
	
	/**
	 * @param id
	 * @param name
	 * @param address
	 * @param birthdate
	 * @param sssNo
	 * @param annualSalary
	 * @param loanAmount
	 */
	public void submitLoanApplication(Integer id, String name, String address, Date birthdate,
									  String sssNo, Double annualSalary, Double loanAmount) {
		
		CustomerHomeRemote customerHome = null;
		CustomerRemote customer = null;
		
		try{
			Context jndiContext = new InitialContext();
			Object obj = jndiContext.lookup("java:comp/env/ejb/CustomerHomeRemote");

			customerHome = (CustomerHomeRemote) PortableRemoteObject.narrow(obj, CustomerHomeRemote.class);
		} catch (NamingException ne){
			System.out.println("Naming Exception: " + ne.getMessage());
		}
		
		try{
			customer = customerHome.create(id, name, sssNo, address, birthdate, annualSalary, loanAmount);
			submit_count++;
		} catch(RemoteException re){
			System.out.println("Remote Exception: " + re.getMessage());
		} catch(CreateException ce){
			System.out.println("Create Exception: " + ce.getMessage());
		}
	}
	
	/**
	 * @return
	 */
	public int getSubmitCount(){
		return submit_count;
	}
	
	/**
	 * @return
	 */
	public int getMaxPK(){
		int maxPK = 0;
		
		CustomerHomeRemote customerHome = null;
		CustomerRemote customer = null;
		
		try{
			Context jndiContext = new InitialContext();
			Object obj = jndiContext.lookup("java:comp/env/ejb/CustomerHomeRemote");

			customerHome = (CustomerHomeRemote) PortableRemoteObject.narrow(obj, CustomerHomeRemote.class);
		} catch (NamingException ne){
			System.out.println("Naming Exception: " + ne.getMessage());
		}
		
		for(int pk = 1;;pk++){
			try{
				customer = customerHome.findByPrimaryKey(new Integer(pk));
			} catch(FinderException fe){
				System.out.println("Find Exception: " + fe.getMessage());
				maxPK = pk - 1;
				break;
			} catch(RemoteException re){
				System.out.println("Remote Exception: " + re.getMessage());
				break;
			}
		}
		
		return maxPK;
	}
	
}