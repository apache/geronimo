package com.ibm.demo.session.stateless;

import javax.ejb.*;
import java.rmi.RemoteException;

/**
 * @author hisidro
 * 
 */
public interface LoanManagerHomeRemote extends EJBHome {

	/**
	 * @return
	 * @throws RemoteException
	 * @throws CreateException
	 */
	public LoanManagerRemote create() throws RemoteException, CreateException;
}