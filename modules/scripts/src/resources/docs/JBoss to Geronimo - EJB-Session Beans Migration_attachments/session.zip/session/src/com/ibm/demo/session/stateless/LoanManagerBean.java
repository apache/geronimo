package com.ibm.demo.session.stateless;

import javax.ejb.*;
import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;

import java.rmi.RemoteException;
import java.util.List;
import java.util.ArrayList;

import com.ibm.demo.entity.CustomerHomeRemote;
import com.ibm.demo.entity.CustomerRemote;

/**
 * @author hisidro
 *
 */
public class LoanManagerBean implements SessionBean{
	
	public void ejbCreate(){}
	public void ejbRemove(){}
	public void ejbActivate(){}
	public void ejbPassivate(){}
	public void setSessionContext(SessionContext ctx){}
	
	/**
	 * @return
	 */
	public List deniedLoans() {
		
		CustomerHomeRemote customerHome = null;
		
		try{
			Context jndiContext = new InitialContext();
			Object obj = jndiContext.lookup("java:comp/env/ejb/CustomerHomeRemote");

			customerHome = (CustomerHomeRemote) PortableRemoteObject.narrow(obj, CustomerHomeRemote.class);
		} catch (NamingException ne){
			System.out.println("Naming Exception: " + ne.getMessage());
		}
		
		List granted = new ArrayList();
		
		//loop through all customers
		CustomerRemote customer = null;
		for (int i = 1; ; i++){
			Integer pk = new Integer(i);
			try{
				customer = customerHome.findByPrimaryKey(pk);
			} catch(FinderException fe){
				System.out.println("Find Exception: " + fe.getMessage());
				break;
			} catch(RemoteException re){
				System.out.println("Remote Exception: " + re.getMessage());
				break;
			}
			// Check to see if the annualSalary to loanAmount ratio is not acceptable (<0.1)
			
			try{
				double ratio = customer.getAnnualSalary().doubleValue() / customer.getLoanAmount().doubleValue();
				if((customer != null)&&(ratio < 0.1)){
					granted.add(customer.getName());
				}
			}catch (RemoteException re){
				System.out.println("Remote Exception: " + re.getMessage());
			}
		}
		return granted;
	}
}