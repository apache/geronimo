package com.ibm.demo.session.stateless;

import javax.ejb.*;
import java.rmi.RemoteException;
import java.util.List;

/**
 * @author hisidro
 *
 */
public interface LoanManagerRemote extends EJBObject{
	
	/**
	 * @return
	 * @throws RemoteException
	 */
	public List deniedLoans() throws RemoteException;
}