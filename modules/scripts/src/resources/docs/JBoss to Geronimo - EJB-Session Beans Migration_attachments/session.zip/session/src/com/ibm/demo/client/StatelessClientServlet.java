package com.ibm.demo.client;

import com.ibm.demo.session.stateless.LoanManagerHomeRemote;
import com.ibm.demo.session.stateless.LoanManagerRemote;

import javax.naming.InitialContext;
import javax.naming.Context;
import javax.naming.NamingException;
import javax.ejb.CreateException;
import javax.rmi.PortableRemoteObject;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletException;
import javax.servlet.ServletContext;

import java.io.IOException;
import java.rmi.RemoteException;
import java.util.List;
import java.util.ArrayList;

/**
 * @author hisidro
 *
 */
public class StatelessClientServlet extends HttpServlet {
	
	private ServletContext ctx;
	private List deniedLoans = new ArrayList();
	private LoanManagerRemote loanmanager;
	
	public void init() throws ServletException {
		try{
			this.ctx = getServletContext();
			
			Context jndiContext = new InitialContext();   
			Object ref = jndiContext.lookup("java:/comp/env/ejb/LoanManagerHomeRemote");   
			LoanManagerHomeRemote home = (LoanManagerHomeRemote)
										  PortableRemoteObject.narrow(ref, LoanManagerHomeRemote.class);

			loanmanager = home.create();
			
		} catch(CreateException ce){
			ce.printStackTrace();
		} catch(RemoteException re){
			re.printStackTrace();
		} catch(NamingException ne){
			ne.printStackTrace();
		} catch(Exception e) {
            e.printStackTrace();
            throw new ServletException(e);
        }
    }

	public void destroy() {

    }

    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	
    	// Get a list of all denied loans
		deniedLoans = loanmanager.deniedLoans();
    	
    	if(deniedLoans==null){
    		System.out.println("No denied loans");
    		deniedLoans.add("No denied loan applications.");
    	}
    	
    	request.setAttribute("customers", deniedLoans);

        ctx.getRequestDispatcher("/stateless.jsp").include(request, response);
    }
	
}
