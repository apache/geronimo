/*
 * Created on Sep 26, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.ibm.demo.entity.bmp;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.Collection;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;
import javax.ejb.FinderException;
import javax.ejb.ObjectNotFoundException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

/**
 * @author cpineda
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
public class CustomerBean implements EntityBean {

	public Integer id;

	public String name;

	public String address;

	public Date birthdate;

	public String sssNo;

	public Double annualSalary;

	public Double loanAmount;

	public EntityContext context;

	/**
	 * 
	 * @param id
	 * @param name
	 * @param sssNo
	 * @param address
	 * @param birthdate
	 * @param annualSalary
	 * @param loanAmount
	 * @return @throws
	 *         CreateException
	 */
	public Integer ejbCreate(Integer id, String name, String sssNo,
			String address, Date birthdate, Double annualSalary,
			Double loanAmount) throws CreateException {
		String insertQuery = "INSERT INTO CUSTOMER "
				+ "(ID,NAME,SSS_NO,BIRTHDATE,ADDRESS,ANNUAL_SALARY,LOAN_AMOUNT)"
				+ " VALUES (?,?,?,?,?,?,?)";
		this.id = id;
		this.name = name;
		this.birthdate = birthdate;
		this.sssNo = sssNo;
		this.address = address;
		this.annualSalary = annualSalary;
		this.loanAmount = loanAmount;
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = this.getConnection();
			ps = conn.prepareStatement(insertQuery);
			ps.setInt(1, id.intValue());
			ps.setString(2, name);
			ps.setString(3, sssNo);
			ps.setDate(4, new java.sql.Date(birthdate.getTime()));
			ps.setString(5, address);
			ps.setDouble(6, annualSalary.doubleValue());
			ps.setDouble(7, loanAmount.doubleValue());
			if (ps.executeUpdate() != 1) {
				throw new CreateException("Failed to Add Customer");
			}
		} catch (SQLException se) {
			throw new EJBException(se);
		} finally {
			try {
				ps.close();
			} catch (Exception e) {
			}
			try {
				conn.close();
			} catch (Exception e) {
			}
		}
		return id;
	}

	/**
	 * 
	 * @param id
	 * @return @throws
	 *         CreateException
	 */
	public Integer ejbCreate(Integer id) throws CreateException {
     	String insertQuery = "INSERT INTO CUSTOMER " + "(ID)" + " VALUES (?)";
		this.id = id;
		Connection conn = null;
		PreparedStatement ps = null;
			try {
			conn = this.getConnection();
			ps = conn.prepareStatement(insertQuery);
			ps.setInt(1, id.intValue());
			if (ps.executeUpdate() != 1) {
				throw new CreateException("Failed to Add Customer");
			}	
		} catch (SQLException se) {
			se.printStackTrace();
			throw new EJBException(se);
		} finally {
			try {
				ps.close();
			} catch (Exception e) {
			}
			try {
				conn.close();
			} catch (Exception e) {
			}
		}
		return id;
	}

	/**
	 * 
	 * @param id
	 * @param name
	 * @param sssNo
	 * @param address
	 * @param birthdate
	 * @param annualSalary
	 * @param loanAmount
	 */
	public void ejbPostCreate(Integer id, String name, String sssNo,
			String address, Date birthdate, Double annualSalary,
			Double loanAmount) {

	}

	/**
	 * 
	 * @param id
	 */
	public void ejbPostCreate(Integer id) {

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.ejb.EntityBean#setEntityContext(javax.ejb.EntityContext)
	 */
	public void setEntityContext(EntityContext context) {
		this.context = context;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.ejb.EntityBean#unsetEntityContext()
	 */
	public void unsetEntityContext() {
		this.context = null;
	}

	/**
	 * 
	 * @param primaryKey
	 * @return @throws
	 *         FinderException
	 */
	public Integer ejbFindByPrimaryKey(Integer primaryKey)
			throws FinderException {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet result = null;
		String query = "SELECT ID FROM CUSTOMER WHERE ID=?";

		try {
			conn = this.getConnection();
			ps = conn.prepareStatement(query);
			ps.setInt(1, primaryKey.intValue());
			result = ps.executeQuery();
			if (!result.next()) {
				throw new ObjectNotFoundException(
						"Customer not found with ID: " + primaryKey);
			}
		} catch (SQLException se) {
			throw new EJBException(se);
		} finally {
			try {
				result.close();
			} catch (Exception e) {
			}
			try {
				ps.close();
			} catch (Exception e) {
			}
			try {
				conn.close();
			} catch (Exception e) {
			}
		}
		return primaryKey;
	}

	/**
	 * 
	 * @param sssNo
	 * @return @throws
	 *         FinderException
	 */
	public Integer ejbFindBySssNo(String sssNo) throws FinderException {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet result = null;
		String query = "SELECT ID FROM CUSTOMER WHERE SSS_NO=?";
		int customerId;

		try {
			conn = this.getConnection();
			ps = conn.prepareStatement(query);
			ps.setString(1, sssNo);
			result = ps.executeQuery();
			if (!result.next()) {
				throw new ObjectNotFoundException(
						"Customer not found with SSS_NO:" + sssNo);
			} else {
				customerId = result.getInt(1);
			}
			if (result.next()) {
				//Invalid state duplicate entry for unique index
				throw new SQLException(
						"Invalid database state.Duplicate entries for unique index SSS_NO");
			}
		} catch (SQLException se) {
			throw new EJBException(se);
		} finally {
			try {
				result.close();
			} catch (Exception e) {
			}
			try {
				ps.close();
			} catch (Exception e) {
			}
			try {
				conn.close();
			} catch (Exception e) {
			}
		}
		return new Integer(customerId);
	}

/**
	 * 
	 * @return @throws
	 *         FinderException
	 */
	public Collection ejbFindAll() throws FinderException {
		Collection ret = new ArrayList();
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet result = null;
		String query = "SELECT ID FROM CUSTOMER";

		try {
			conn = this.getConnection();
			ps = conn.prepareStatement(query);
			result = ps.executeQuery();
			while(result.next()) {
				ret.add(new Integer(result.getInt(1)));
			}
		} catch (SQLException se) {
			throw new EJBException(se);
		} finally {
			try {
				result.close();
			} catch (Exception e) {
			}
			try {
				ps.close();
			} catch (Exception e) {
			}
			try {
				conn.close();
			} catch (Exception e) {
			}
		}
		return ret;
	}
	
	public void ejbActivate() {
		// Not implemented.
	}

	public void ejbPassivate() {
		// Not implemented.
	}

	public void ejbLoad() {

		Integer primaryKey = (Integer) context.getPrimaryKey();
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet result = null;
		String query = "SELECT NAME,BIRTHDATE,SSS_NO,ADDRESS,ANNUAL_SALARY,LOAN_AMOUNT"
				+ " FROM CUSTOMER WHERE ID=?";
		try {
			conn = this.getConnection();
			ps= conn.prepareStatement(query);
			ps.setInt(1, primaryKey.intValue());
			result = ps.executeQuery();

			if (result.next()) {
				this.id = primaryKey;
				this.name = result.getString(1);
				this.birthdate = new Date(result.getDate(2).getTime());
				this.sssNo = result.getString(3);
				this.address = result.getString(4);
				this.annualSalary = new Double(result.getDouble(5));
				this.loanAmount = new Double(result.getDouble(6));

			} else {
				throw new EJBException();
			}
		} catch (SQLException se) {
			throw new EJBException(se);
		} finally {
			try {
				result.close();
			} catch (Exception e) {
			}
			try {
				ps.close();
			} catch (Exception e) {
			}
			try {
				conn.close();
			} catch (Exception e) {
			}
		}
	}

	public void ejbStore() {
		String updateQuery = "UPDATE CUSTOMER SET NAME=?, BIRTHDATE=?, SSS_NO=?, ADDRESS=?,ANNUAL_SALARY=?,LOAN_AMOUNT=? WHERE ID=?";
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = this.getConnection();
			ps = conn.prepareStatement(updateQuery);
			ps.setString(1, name);
			ps.setDate(2, new java.sql.Date(birthdate.getTime()));
			ps.setString(3, sssNo);
			ps.setString(4, address);
			ps.setDouble(5, annualSalary.doubleValue());
			ps.setDouble(6, loanAmount.doubleValue());
			ps.setInt(7, id.intValue());
			ps.executeUpdate();
			/*if (ps.executeUpdate() != 1) {
				throw new EJBException("ejbStore unable to update table");
			}*/
		} catch (SQLException se) {
			se.printStackTrace();
			throw new EJBException(se);
		} finally {
			try {
				ps.close();
			} catch (Exception e) {
			}
			try {
				conn.close();
			} catch (Exception e) {
			}
		}
	}

	public void ejbRemove() {
		String deleteQuery = "DELETE FROM CUSTOMER WHERE ID=?";
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = this.getConnection();
			ps = conn.prepareStatement(deleteQuery);
			ps.setInt(1, id.intValue());
			if (ps.executeUpdate() != 1) {
				throw new EJBException("ejbStore unable to update table");
			}
		} catch (SQLException se) {
			throw new EJBException(se);
		} finally {
			try {
				ps.close();
			} catch (Exception e) {
			}
			try {
				conn.close();
			} catch (Exception e) {
			}
		}
	}

	/**
	 * 
	 * @return @throws
	 *         SQLException
	 */
	private Connection getConnection() throws SQLException {
		try {
			Context jndiCntx = new InitialContext();
			DataSource ds = (DataSource) jndiCntx
					.lookup("java:comp/env/jdbc/ibm-demo");
			return ds.getConnection();
		} catch (NamingException ne) {
			ne.printStackTrace();
			throw new EJBException(ne);
		}
	}

	/**
	 * @return Returns the address.
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @param address
	 *            The address to set.
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * @return Returns the annualSalary.
	 */
	public Double getAnnualSalary() {
		return annualSalary;
	}

	/**
	 * @param annualSalary
	 *            The annualSalary to set.
	 */
	public void setAnnualSalary(Double annualSalary) {
		this.annualSalary = annualSalary;
	}

	/**
	 * @return Returns the birthdate.
	 */
	public Date getBirthdate() {
		return birthdate;
	}

	/**
	 * @param birthdate
	 *            The birthdate to set.
	 */
	public void setBirthdate(Date birthdate) {
		this.birthdate = birthdate;
	}

	/**
	 * @return Returns the loanAmount.
	 */
	public Double getLoanAmount() {
		return loanAmount;
	}

	/**
	 * @param loanAmount
	 *            The loanAmount to set.
	 */
	public void setLoanAmount(Double loanAmount) {
		this.loanAmount = loanAmount;
	}

	/**
	 * @return Returns the name.
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            The name to set.
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return Returns the sssNo.
	 */
	public String getSssNo() {
		return sssNo;
	}

	/**
	 * @param sssNo
	 *            The sssNo to set.
	 */
	public void setSssNo(String sssNo) {
		this.sssNo = sssNo;
	}
}