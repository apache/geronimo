package com.dev.trade.bo;

public class User {

	private String userId = null;
	private String name = null;
	private String password = null;
	private String address = null;
	private float cash = 0f;
	
	public User(String userId,String name,String password,String address,float cash){		
		this.userId = userId;
		this.name = name;
		this.password = password;
		this.address = address;
		this.cash = cash;
	}
	
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}

	public float getCash() {
		return cash;
	}

	public void setCash(float cash) {
		this.cash = cash;
	}
	
}
