

CREATE TABLE IF NOT EXISTS Users
(userid VARCHAR(15) PRIMARY KEY CHECK (NOT NULL),
name VARCHAR(50),
password VARCHAR(24),
address VARCHAR(96),
cash FLOAT) ;


CREATE TABLE IF NOT EXISTS TradingAccount
(userid VARCHAR(15),
 stockid VARCHAR(8),
 quantity INT);
 

CREATE TABLE IF NOT EXISTS stocks
(id VARCHAR(8) PRIMARY KEY CHECK (NOT NULL),
 name VARCHAR(100),
 price FLOAT);

DELETE FROM Users;
DELETE FROM TradingAccount;
DELETE FROM stocks;

INSERT INTO Users VALUES('srini', '6 Inch',
 'cheemu','Madivala Bangalore',10000);
 
INSERT INTO Users VALUES('j2ee', 'Lee Whittaker',
 'password','Tampa Florida',100000);

INSERT INTO TradingAccount VALUES('j2ee','00000002',10);
INSERT INTO TradingAccount VALUES('srini','00000001',100);

INSERT INTO stocks VALUES('00000001',"BTDA",1.00);
INSERT INTO stocks VALUES('00000002',"Hitech Software",2.00);
INSERT INTO stocks VALUES('00000003',"Bill's Cold Storage",3.00);
INSERT INTO stocks VALUES('00000004',"Colonel's Fried Chicken",300.00);
INSERT INTO stocks VALUES('00000005',"Toyo Motors",30.00);
INSERT INTO stocks VALUES('00000006',"Timbuctoo Airlines",53.00);
INSERT INTO stocks VALUES('00000007',"Happy Undertakers",73.00);
INSERT INTO stocks VALUES('00000008',"Wacko Brothers",54.00);
INSERT INTO stocks VALUES('00000009',"Mental Studios",456.00);
INSERT INTO stocks VALUES('00000013',"ASFG",54.89);
INSERT INTO stocks VALUES('00000023',"BFG",564.50);
INSERT INTO stocks VALUES('00000033',"Mack",3444.50);
INSERT INTO stocks VALUES('00000043',"Ronan & Sons",7.50);
INSERT INTO stocks VALUES('00000053',"Bulls & Bears",553.40);
INSERT INTO stocks VALUES('00000343',"HGHU",456.00);
INSERT INTO stocks VALUES('00000603',"TTTM",77.00);
INSERT INTO stocks VALUES('00000463',"GRASF",88.00);
commit;




