/*
 * Created on Sep 27, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.ibm.demo.mdb.ejb;

import com.ibm.demo.entity.bmp.CustomerRemote;
import com.ibm.demo.entity.bmp.CustomerHomeRemote;

import javax.ejb.MessageDrivenBean;
import javax.ejb.MessageDrivenContext;
import javax.rmi.PortableRemoteObject;
import javax.naming.*;
import javax.jms.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.*;


public class SampleMDB implements MessageDrivenBean, MessageListener {
    static final Logger logger = Logger.getLogger(SampleMDB.class.getName());
    private transient MessageDrivenContext mdc = null;
    private Context ctx;

    public void setMessageDrivenContext(MessageDrivenContext mdc) { this.mdc = mdc; }


    public void onMessage(Message msg) {
    	
        TextMessage txtMsg = null;
        
        try {
            if (msg instanceof TextMessage) {
                txtMsg = (TextMessage) msg;
                logger.info("Received TextMessage: " + txtMsg.getText());
                
                Context initial = new InitialContext();
                NamingEnumeration n = initial.list(initial.getNameInNamespace());
                while(n.hasMoreElements()) System.out.println(n.next());
                Object objref = initial.lookup("java:comp/env/CustomerHomeRemote");
                CustomerHomeRemote home = (CustomerHomeRemote) PortableRemoteObject.narrow(objref,CustomerHomeRemote.class);
                CustomerRemote customer = home.create(new Integer(txtMsg.getIntProperty("customerID")),txtMsg.getStringProperty("customerName"),
                		txtMsg.getStringProperty("customerSSS"),txtMsg.getStringProperty("customerAddress"), new SimpleDateFormat("mm/dd/yyyy").parse(txtMsg.getStringProperty("birthdate")),
						new Double(txtMsg.getDoubleProperty("customerSalary")),new Double(txtMsg.getDoubleProperty("customerLoan")));
                logger.info("SUCCESS!!!");
                
            } else {
                logger.info("Received message of type: " + msg.getClass().getName());
            }
        } catch (JMSException e) {
            e.printStackTrace();
            mdc.setRollbackOnly();
        } catch (Throwable te) {
            te.printStackTrace();
        }
    }

    public void ejbRemove() { }
    public void ejbCreate() {   }
}