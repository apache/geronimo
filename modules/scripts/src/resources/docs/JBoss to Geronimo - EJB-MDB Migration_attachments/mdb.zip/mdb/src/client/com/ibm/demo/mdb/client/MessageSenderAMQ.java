/*
 * Created on Oct 11, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.ibm.demo.mdb.client;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;

import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingEnumeration;

import org.activemq.ActiveMQConnection;
import org.activemq.ActiveMQConnectionFactory;
import org.activemq.ActiveMQMessageProducer;

/**
 * @author exist_user2
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class MessageSenderAMQ {

	public static void main(String[] args) throws Exception {

		ActiveMQConnectionFactory connectionFactory = 
			new ActiveMQConnectionFactory("tcp://localhost:61616");
		
		QueueConnection connection = (QueueConnection)connectionFactory.createConnection();		
		
		try {
			Session session = connection.createQueueSession(false,Session.AUTO_ACKNOWLEDGE);
			Queue queue = session.createQueue("SendReceiveQueue");		
			MessageProducer sender = session.createProducer(queue);
			TextMessage message = session.createTextMessage("add customer");
			
		    //  Get text from standard input.
		    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			String t = null;
		    // Prompt user for information and add to message properties.
		    System.out.println("Enter information for new customer.");
		    System.out.print("Enter customer id (Integer):");
		    t = br.readLine();
		    message.setIntProperty("customerID",Integer.parseInt(t));
		    System.out.print("Enter name:");
		    t = br.readLine();
		    message.setStringProperty("customerName",t);
		    System.out.print("Enter sss number:");
		    t = br.readLine();
		    message.setStringProperty("customerSSS",t);
		    System.out.print("Enter address:");
		    t = br.readLine();
		    message.setStringProperty("customerAddress",t);
		    System.out.print("Enter birhtdate (mm/dd/yyyy):");
		    t = br.readLine();
		    message.setStringProperty("birthdate", t);
		    System.out.print("Enter annual salary:");
		    t = br.readLine();
		    message.setDoubleProperty("customerSalary", Double.parseDouble(t));
		    System.out.print("Enter loan amount:");
		    t = br.readLine();
		    message.setDoubleProperty("customerLoan", Double.parseDouble(t));
		    
		    
			sender.send(message);
			System.out.println("Message sent.");

		} finally {
			connection.close();
		}
	}

}
