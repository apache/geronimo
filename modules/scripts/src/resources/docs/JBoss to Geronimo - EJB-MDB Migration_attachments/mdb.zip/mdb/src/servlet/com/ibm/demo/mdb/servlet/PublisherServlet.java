package com.ibm.demo.mdb.servlet;

import javax.servlet.ServletException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.naming.InitialContext;
import javax.jms.*;
import java.io.IOException;

public class PublisherServlet extends javax.servlet.http.HttpServlet {

    private ServletContext ctx;
    private QueueConnection connection;
    private Queue queue;

    public void init() throws ServletException {

        this.ctx = getServletContext();

        String connectionFactoryName = "java:comp/env/jms/broker";
        String queueName = "java:comp/env/jms/queue/DefQueue";

        try {
            InitialContext naming = new InitialContext();


            // lookup queue connection factory
            QueueConnectionFactory connectionFactory =
                    (QueueConnectionFactory) naming.lookup(connectionFactoryName);


            // create jms connection
            connection = connectionFactory.createQueueConnection();

            // lookup jms queue
            queue = (Queue) naming.lookup(queueName);
        }
        catch(Exception e) {
            e.printStackTrace();
            throw new ServletException(e);
        }
    }

    public void destroy() {
        if (connection != null) {
            try {
                if (connection != null) {
                    connection.close();
                }
            }
            catch (Exception e) {          }
        }
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // one session per-thread
        QueueSession publishSession = null;
        RequestDispatcher rd = null;

        try {
            // create jms session
            boolean transacted = false;
            publishSession = connection.createQueueSession(transacted, Session.AUTO_ACKNOWLEDGE);

            QueueSender sender = publishSession.createSender(queue);
			sender.setDeliveryMode(DeliveryMode.PERSISTENT);
			

            TextMessage message = publishSession.createTextMessage("add customer");
		    // Get new user information from request and populate the message with that info.
		    message.setIntProperty("customerID",Integer.parseInt(request.getParameter("clientID")));
		    message.setStringProperty("customerName",request.getParameter("clientName"));
		    message.setStringProperty("customerSSS",request.getParameter("clientSSS"));
		    message.setStringProperty("customerAddress",request.getParameter("clientSSS"));
		    message.setStringProperty("birthdate", request.getParameter("clientBirthdate"));
		    message.setDoubleProperty("customerSalary", Double.parseDouble(request.getParameter("clientSalary")));
		    message.setDoubleProperty("customerLoan", Double.parseDouble(request.getParameter("loanAmt")));
            sender.send(message);


            rd = ctx.getRequestDispatcher("/list.jsp");
            rd.forward(request, response);
        }
        catch(Exception e) {
            throw new ServletException(e);
        }
        finally {
            try {
                if (publishSession != null) {
                    publishSession.close();
                }
            }
            catch (Exception e) {}
        }
    }
}
