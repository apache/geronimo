package com.ibm.demo.mdb.client;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Properties;

import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;

public class MessageSenderJBoss {

	public static void main(String[] args) throws Exception {

		// Set up context
		Properties properties = new Properties();
		properties.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		properties.put(Context.URL_PKG_PREFIXES, "org.jnp.interfaces");
		properties.put(Context.PROVIDER_URL, "localhost");
		InitialContext ctx = new InitialContext(properties);

		// Lookup queue and connection factory.
		Queue queue = (Queue) ctx.lookup("queue/testQueue");
		QueueConnectionFactory qcf = (QueueConnectionFactory) ctx.lookup("UIL2ConnectionFactory");

		QueueConnection qc = qcf.createQueueConnection();
		
		try {
			QueueSession qs = qc.createQueueSession(false,Session.AUTO_ACKNOWLEDGE);
			QueueSender sender = qs.createSender(queue);
			TextMessage message = qs.createTextMessage("add customer");
			
		    //  Get text from standard input.
		    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			String t = null;
		    // Prompt user for information and add to message properties.
		    System.out.println("Enter information for new customer.");
		    System.out.print("Enter customer id (Integer):");
		    t = br.readLine();
		    message.setIntProperty("customerID",Integer.parseInt(t));
		    System.out.print("Enter name:");
		    t = br.readLine();
		    message.setStringProperty("customerName",t);
		    System.out.print("Enter sss number:");
		    t = br.readLine();
		    message.setStringProperty("customerSSS",t);
		    System.out.print("Enter address:");
		    t = br.readLine();
		    message.setStringProperty("customerAddress",t);
		    System.out.print("Enter birhtdate (mm/dd/yyyy):");
		    t = br.readLine();
		    message.setStringProperty("birthdate", t);
		    System.out.print("Enter annual salary:");
		    t = br.readLine();
		    message.setDoubleProperty("customerSalary", Double.parseDouble(t));
		    System.out.print("Enter loan amount:");
		    t = br.readLine();
		    message.setDoubleProperty("customerLoan", Double.parseDouble(t));
		    
		    
			sender.send(message);


		} finally {
			qc.close();
		}
	}
}