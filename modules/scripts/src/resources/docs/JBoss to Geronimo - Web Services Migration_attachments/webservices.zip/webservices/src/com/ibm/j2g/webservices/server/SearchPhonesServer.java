/*****************************************************************
 *   File: SearchPhonesServer.java
 *   
 *   Date         Version   Author               Changes
 *   Sep.30,2005  1.1       Vladimir Shraibman   Created
 *
 *   Copyright (c) 2005, IBM Corporation
 *   All rights reserved.
 *****************************************************************/
package com.ibm.j2g.webservices.server;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

/**
 * This class implements the Search Phones web service.
 * All sample data is hard coded.
 * 
 * @author Vladimir B. Shraibman <shvb@isg.axmor.com>
 */
public class SearchPhonesServer implements SearchPhonesPortType {

    /** 
     * Sample phones data
     */
    public final static PersonPhone[] AVAILABLE_PHONES = new PersonPhone[] {
        new PersonPhone("Tom", "098-765-4321"),
        new PersonPhone("John", "908-123-4567"),
        new PersonPhone("Laura", "098-132-7654"),
        new PersonPhone("Paul", "980-567-1234"),
        new PersonPhone("Mike", "809-321-7654"),
        new PersonPhone("Helen", "089-675-1234"),
        new PersonPhone("Bill", "890-213-7654"),
        new PersonPhone("Mark", "908-312-4567"),
        new PersonPhone("Jenny", "809-756-4321"),
        new PersonPhone("Brian", "980-576-1234")
    };
    
    /**
     * Searches sample data for persons which name starts with the specified string and returns
     * an array of found persons with their phones
     * @param personName string for which names of persons are to be searched
     * @return array of found persons with their phones or null in case the search parameter
     *         is null or equals to an empty string
     */
    public PersonPhone[] search(String personName) throws RemoteException {
        if (personName == null || personName.equals("")) {
            return null;
        }

        String stringToSearch = personName.toLowerCase();
                
        List results = new ArrayList();
        for (int i = 0; i < AVAILABLE_PHONES.length; i++) {
            if (AVAILABLE_PHONES[i].getPersonName().toLowerCase().startsWith(stringToSearch)) {
                results.add(AVAILABLE_PHONES[i]);
            }
        }
        
        return (PersonPhone[])results.toArray(new PersonPhone[results.size()]);
    }
}
