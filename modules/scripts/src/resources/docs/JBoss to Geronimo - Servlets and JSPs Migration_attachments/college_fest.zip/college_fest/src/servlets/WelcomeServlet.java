
package servlets;

import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;


/**
 * This is a simple example of an HTTP Servlet.  It responds to the GET
 * method of the HTTP protocol.
 */

public class WelcomeServlet extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        response.setContentType("text/html");
        response.setBufferSize(8192);

        PrintWriter out = response.getWriter();

        // then write the data of the response
        out.println("<html>" + "<head><title>Welcome</title></head>");

        // then write the data of the response
         out.println("<body background=\"pix/98.jpg\" alt=\"Aatmatrisha\">"  +
         		"<font face=\"Garamond\">"+
								
            
         		"<center><h1 style=\"color:white\">Aatmatrisha'05 - the annual PESIT college fest </h1></center>" +
	            "<form  method=\"get\">" +
	            "<center><h2 style=\"color:white\">Login Page </h1></center>" +
	            "<form  method=\"get\">" +
			"<h3 style=\"color:white\"> Name                  :   </h3>" +
            "<input type=\"text\" name=\"username\" size=\"25\">" + "<p></p>" +		
            "<h3 style=\"color:white\">College               :   </h3>" +
			            "<input type=\"text\" name=\"college\" size=\"25\">" + "<p></p>" +
            "<input type=\"submit\" value=\"Submit\">" +
            "<input type=\"reset\" value=\"Reset\">" + "</font>"+
        "</form>");

        String username = request.getParameter("username");
        

        if ((username != null) && (username.length() > 0)) {
            RequestDispatcher dispatcher =
                getServletContext()
                    .getRequestDispatcher("/personal");
// wrapper for the servlet 
            if (dispatcher != null) {
                dispatcher.include(request, response);
            }
        }

        out.println("</body></html>");
        out.close();
    }

    public String getServletInfo() {
        return "The College Fest servlet welcomes you!";
    }
}
