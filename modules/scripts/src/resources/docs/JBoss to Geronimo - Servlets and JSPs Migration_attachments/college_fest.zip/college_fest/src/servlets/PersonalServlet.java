


package servlets;

import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;


/**
 * This is a simple example of an HTTP Servlet.  It responds to the GET
 * method of the HTTP protocol.
 */

public class PersonalServlet extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        
    	PrintWriter out = response.getWriter();

        // then write the data of the response
    	
        String username = request.getParameter("username");
       
        out.println("<html>" + "<head><title>Welcome</title></head>");
        
        if ((username != null) && (username.length() > 0)) {
        	
        	out.println("<body>");
        	out.println("<font size=\"15\"color=\"white\" face=\"Garamond\">");
        			
        	out.println("<center>Hello, " + username + "!");
        	out.println("Click <a href=\"jsp/welcome.jsp\"> here </a> to enter the site  </center>");
            out.println("</font></body></html>");
        		           
        }
    }

    public String getServletInfo() {
        return "Welcome to your personalised page !";
    }
    
}
