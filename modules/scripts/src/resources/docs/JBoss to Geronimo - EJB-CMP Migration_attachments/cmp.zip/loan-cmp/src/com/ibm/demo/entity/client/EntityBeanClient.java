/*
 * Created on Sep 27, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.ibm.demo.entity.client;

/**
 * @author cpineda
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
import java.rmi.RemoteException;
import java.util.Date;

import javax.naming.InitialContext;
import javax.naming.Context;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;
import com.ibm.demo.entity.cmp.*;

public class EntityBeanClient {

	public static void main(String[] arg) {
		try {
			Context jndiContext = getInitialContext();

			String name = "CustomerHomeRemote";

			Object ref = jndiContext.lookup(name);
			System.out.println("creating home...");
			CustomerHomeRemote home = (CustomerHomeRemote) PortableRemoteObject
					.narrow(ref, CustomerHomeRemote.class);
			CustomerRemote customerRemote = null;
            System.out.println("creating customer...");
            try{
            System.out.println("INSERTING RECORD :"+ "1, Customer 1, 11/11/11,  2323232 , NO INFO,  "+ new Double(0.0)+" , "+new Double(0.0));
				customerRemote = home.create(new Integer(1), "Customer 1", new Date("11/11/11"), "2323232", "NO INFO", new Double(0.0),new Double(0.0));
	    System.out.println("DONE WITH THE INSERT");
		}catch(Exception e){/* this will most likely be because the customer already exists in the database. */ 
		  
		}
            System.out.print("done.");

            System.out.println("findByPrimaryKeyTest... 1");
            customerRemote = null;
            customerRemote = home.findByPrimaryKey(new Integer(1));
            System.out.println("customer name: "+customerRemote.getName());
            System.out.println("customer sss no: "+customerRemote.getSssNo());
            System.out.println("customer loan amount: "+customerRemote.getLoanAmount());
            System.out.println("customer annual salary: "+customerRemote.getAnnualSalary());
            System.out.println("customer birthdate: "+customerRemote.getBirthdate());

            System.out.println("updating ejb...");
            customerRemote.setName("Customer 2");
            System.out.print("done.");

            System.out.println("findBySssNoTest... 2323232");
            customerRemote = null;
            customerRemote = home.findBySssNo("2323232");
            System.out.println("customer name: "+customerRemote.getName());
            System.out.println("customer sss no: "+customerRemote.getSssNo());
            System.out.println("customer loan amount: "+customerRemote.getLoanAmount());
            System.out.println("customer annual salary: "+customerRemote.getAnnualSalary());
            System.out.println("customer birthdate: "+customerRemote.getBirthdate());

            customerRemote.remove();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static Context getInitialContext()
			throws javax.naming.NamingException {
		return new javax.naming.InitialContext();
	}
}