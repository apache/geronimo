/*
 * Created on Sep 26, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.ibm.demo.entity.cmp;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.Collection;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;
import javax.ejb.FinderException;
import javax.ejb.ObjectNotFoundException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

/**
 * @author cpineda
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
public abstract class CustomerBean implements EntityBean {

        public Integer id;
	public String name;

	public String address;

	public Date birthdate;

	public String sssNo;

	public Double annualSalary;

	public Double loanAmount;

	public EntityContext context;

	/**
	 * 
	 * @param id
	 * @param name
	 * @param sssNo
	 * @param address
	 * @param birthdate
	 * @param annualSalary
	 * @param loanAmount
	 * @return @throws
	 *         CreateException
	 */
	public Integer ejbCreate(Integer id,String name,Date birthdate,String sssNo,String address,
								 Double annualSalary,Double loanAmount) throws CreateException{
		setId(id);
		setName(name);
		setBirthdate(birthdate);
		setSssNo(sssNo);
		setAddress(address);
		setAnnualSalary(annualSalary);
		setLoanAmount(loanAmount);
		
		return id;
	}

	/**
	 * 
	 * @param id
	 * @return @throws
	 *         CreateException
	 */
	/**
	 * 
	 * @param id
	 * @return @throws
	 *         CreateException
	 */
	public Integer ejbCreate(Integer id) throws CreateException {
		
		setId(id);
		return id;
	}


	/**
	 * 
	 * @param id
	 * @param name
	 * @param sssNo
	 * @param address
	 * @param birthdate
	 * @param annualSalary
	 * @param loanAmount
	 */
	public void ejbPostCreate(Integer id, String name,Date birthdate,String sssNo,String address,
								 Double annualSalary,Double loanAmount) {
				
	}



	/**
	 * 
	 * @param id
	 */
	public void ejbPostCreate(Integer id) {

	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.ejb.EntityBean#setEntityContext(javax.ejb.EntityContext)
	 */
	public void setEntityContext(EntityContext context) {
		this.context = context;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.ejb.EntityBean#unsetEntityContext()
	 */
	public void unsetEntityContext() {
		this.context = null;
	}

	
	public void ejbActivate() {
		// Not implemented.
	}

	public void ejbPassivate() {
		// Not implemented.
	}

	public void ejbLoad() {

		
	}

	public void ejbStore() {
		
	}

	public void ejbRemove() {}

	/**
	 * @return Returns the address.
	 */
	public abstract String getAddress();

	/**
	 * @param address
	 *            The address to set.
	 */
	public abstract void setAddress(String address);

	/**
	 * @return Returns the annualSalary.
	 */
	public abstract Double getAnnualSalary();

	/**
	 * @param annualSalary
	 *            The annualSalary to set.
	 */
	public abstract void setAnnualSalary(Double annualSalary);

	/**
	 * @return Returns the birthdate.
	 */
	public abstract Date getBirthdate();

	/**
	 * @param birthdate
	 *            The birthdate to set.
	 */
	public abstract void setBirthdate(Date birthdate);

	/**
	 * @return Returns the loanAmount.
	 */
	public abstract Double getLoanAmount();

	/**
	 * @param loanAmount
	 *            The loanAmount to set.
	 */
	public abstract void setLoanAmount(Double loanAmount);

	/**
	 * @return Returns the name.
	 */
	public abstract String getName();

	/**
	 * @param name
	 *            The name to set.
	 */
	public abstract void setName(String name);

	/**
	 * @return Returns the sssNo.
	 */
	public abstract String getSssNo();

	/**
	 * @param sssNo
	 *            The sssNo to set.
	 */
	public abstract void setSssNo(String sssNo);
	
	
	/**
	 * @return Returns the ID.
	 */
	public abstract Integer getId();

	/**
	 * @param Id
	 *            The Id to set.
	 */
	public abstract void setId(Integer id);

}