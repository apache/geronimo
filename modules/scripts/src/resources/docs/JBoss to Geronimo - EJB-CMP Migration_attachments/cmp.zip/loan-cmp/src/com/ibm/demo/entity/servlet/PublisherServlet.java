package com.ibm.demo.entity.servlet;

import com.ibm.demo.entity.cmp.*;

import javax.servlet.ServletException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;

import java.text.SimpleDateFormat;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: simon
 * Date: Nov 13, 2004
 * Time: 10:07:03 AM
 * To change this template use File | Settings | File Templates.
 */
public class PublisherServlet extends javax.servlet.http.HttpServlet {

    private ServletContext ctx;

    public void init() throws ServletException {

        this.ctx = getServletContext();
    }


    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        RequestDispatcher rd = null;

        try {
			InitialContext jndiContext = new InitialContext();

			String name = "java:comp/env/ejb/CustomerHome";

			Object ref = jndiContext.lookup(name);
			CustomerHomeRemote home = (CustomerHomeRemote) PortableRemoteObject.narrow(ref, CustomerHomeRemote.class);
			CustomerRemote customerRemote = null;
            System.out.println("creating customer...");
            try{
				Integer customerID = new Integer(request.getParameter("clientID"));
			    String customerName = request.getParameter("clientName");
			    String customerSSS = request.getParameter("clientSSS");
			    String customerAddress = request.getParameter("clientSSS");
			    String birthdate = request.getParameter("clientBirthdate");
			    Double customerSalary = new Double(request.getParameter("clientSalary"));
			    Double customerLoan = new Double(request.getParameter("loanAmt"));

				customerRemote = home.create(customerID,customerName,new SimpleDateFormat("mm/dd/yyyy").parse(birthdate),customerSSS,customerAddress,customerSalary,customerLoan);
			}catch(Exception e){/* this will most likely be because the customer already exists in the database. */ }

            rd = ctx.getRequestDispatcher("/list.jsp");
            rd.forward(request, response);
        }
        catch(Exception e) {
            throw new ServletException(e);
        }
    }
}
